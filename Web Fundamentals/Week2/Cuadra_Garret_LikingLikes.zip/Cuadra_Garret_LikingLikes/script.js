function increaseLikes(id) {
    let element = document.querySelector(id);
    element.innerText++;
}