function logout(element) {
    element.innerText = 'Logout';
}

function removeFromDOM(element)    {
    element.remove();
}

function box(element)   {
    alert('Ninja was liked');
}