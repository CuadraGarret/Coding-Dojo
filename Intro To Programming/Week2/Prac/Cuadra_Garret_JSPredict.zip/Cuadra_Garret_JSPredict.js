//PREDICT 1
//Coding Block waiting to be run
function myBirthYearFunc(){
//will write out in the console "I was born in1980"
    console.log("I was born in" + 1980);
}
//Runs the function
myBirthYearFunc();

//PREDICT 2
//coding block waiting to be run
function myBirthYearFunc(birthYearInput){
//will write out in the console "I was born in" and whatever is inputted in (birthYearInput)
    console.log("I was born in" + birthYearInput);
}
//runs function = "I was born in1980" 
myBirthYearFunc(1980);

//PREDICT 3
//coding block waiting to be run
function add(num1, num2){
//logs "Summing Numbers!"
    console.log("Summing Numbers!");
//logs "num1 is: 10"
    console.log("num1 is: " + num1);
//logs "num2 is: 20"
    console.log("num2 is: " + num2);
//creates variable named sum adding both num1 and num2
    var sum = num1 + num2; 
//logs "30"
    console.log(sum);
}
//run function
add(10, 20);