
// Variable for function

var likeCount = 0;

// Function starts the equation using the variable

function increaselikes() {

// Inputs the variables + 1

likeCount = likeCount + 1;
}