
// Variables for requirements of theme park ride

var minimum_height = 42;
var minimum_age = 10;