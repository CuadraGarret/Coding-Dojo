//height and age of variable 

var height = 42;
var age = 10;

//Height and age condition for ride

if (height>=42 || age>=10)
{

//What to do if 1st condition is true

    console.log('Get on that ride, kiddo!');
}

//2nd condition if 1st statement is false

else
{

    console.log('Sorry kiddo. Maybe next year.');

}
